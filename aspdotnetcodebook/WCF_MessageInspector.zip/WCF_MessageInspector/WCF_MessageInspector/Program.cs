﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace WCF_MessageInspector
{
    [ServiceContract]
    public interface IHelloService
    {
        [OperationContract]
        string Greet(string name);
    }
    [ConsoleServiceBehavior]
    [ServiceBehavior]
    public class HelloService : IHelloService
    {
        public string Greet(string name)
        {
            return "Hello ," + name;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            string baseUrl = "http://localhost:12345";
            ServiceHost host = new ServiceHost(typeof(HelloService),new Uri(baseUrl));
            host.AddServiceEndpoint(typeof(IHelloService), new BasicHttpBinding(), "basic");
            // Check to see if the service host already has a ServiceMetadataBehavior
            ServiceMetadataBehavior smb = host.Description.Behaviors.Find<ServiceMetadataBehavior>();
            // If not, add one
            if (smb == null)
                smb = new ServiceMetadataBehavior();
            smb.HttpGetEnabled = true;
            smb.MetadataExporter.PolicyVersion = PolicyVersion.Policy15;
            host.Description.Behaviors.Add(smb);
           
            host.Open();
            Console.WriteLine("Service is ready");
            Console.Read();
        }
    }
}
