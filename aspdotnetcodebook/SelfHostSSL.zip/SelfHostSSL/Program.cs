﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace SelfHostSSL
{
    [ServiceContract]
    public interface IGreeting
    {
        [OperationContract]
        string SendGreeting();
    }

    [ServiceBehavior]
    public class Implementation : IGreeting
    {
        
        [OperationBehavior]

        public string SendGreeting()
        {
            return "Hello world";
        }

        
    }

    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(Implementation));
            host.Open();
            Console.WriteLine("Service is ready");
            Console.ReadLine();
        }
    }
}
