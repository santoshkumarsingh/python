﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Client
{
    [ServiceContract]
    public interface IGreeting
    {
        [OperationContract]
        string SendGreeting();
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            ChannelFactory<IGreeting> proxy = new ChannelFactory<IGreeting>(new BasicHttpBinding());
            proxy.Endpoint.Address = new EndpointAddress("https://localhost:4490/basic");
            string result = proxy.CreateChannel().SendGreeting();
            Console.WriteLine(result);
        }
    }
}
