﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SandboxApplication.Alerts;

namespace SandboxApplication
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            button1.Click += new RoutedEventHandler(button1_Click);
            button2.Click += new RoutedEventHandler(button2_Click);
        }

        void button1_Click(object sender, RoutedEventArgs e)
        {
            SimpleAlert simpleAlert = new SimpleAlert();
            simpleAlert.Title = "My alert has a sample title";
            simpleAlert.Message = "This is my message! If it's long enough it will wrap. Is it long enough now?";
        }

        void button2_Click(object sender, RoutedEventArgs e)
        {
            ImageAlert imageAlert = new ImageAlert();
            imageAlert.Title = "Alert from Google";
            imageAlert.Url = "http://www.google.com/intl/en_ALL/images/logo.gif";
        }
    }
}
