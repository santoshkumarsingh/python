﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Xml.Linq;

namespace FacebookManager
{
    class Program
    {
        private const string API_KEY = "fb8fd2f1ba1f96342a2d0f1f086e5212";
        private const string API_SECRET = "d7bdfa468f5ae597be291ea0d2157de7";
        public static string CreateToken(string apiKey, string secret)
        {
            // Defines the REST API URL.
            string host = "http://api.facebook.com/restserver.php";
            // The returned result.
            string result = string.Empty;

            // The raw signature string.
            string _signature =
            "api_key="
            + apiKey
            + "method=Auth.createToken"
            + "v=1.0"
            + secret;

            // Create the MD5 hash of the raw signature string.
            MD5 md5 = MD5.Create();
            byte[] init = Encoding.ASCII.GetBytes(_signature);
            byte[] hash = md5.ComputeHash(init);
            StringBuilder signature = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                signature.Append(hash[i].ToString("X2"));
            }

            // Prepare the parameters that will be passed to the server.
            Dictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("api_key", apiKey);
            parameters.Add("method", "Auth.createToken");
            parameters.Add("sig", signature.ToString().ToLower());
            parameters.Add("v", "1.0");

            // Build the request string with the parameters above.
            StringBuilder requestParams = new StringBuilder();
            foreach (string key in parameters.Keys)
            {
                if (requestParams.Length != 0)
                    requestParams.Append("&");

                requestParams.Append(key);
                requestParams.Append("=");
                requestParams.Append(System.Web.HttpUtility.HtmlEncode(parameters[key]));
            }

            // Build the request and write the parameters.
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(host);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = requestParams.ToString().Length;

            using (Stream writeStream = request.GetRequestStream())
            {
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] bytes = encoding.GetBytes(requestParams.ToString());
                writeStream.Write(bytes, 0, bytes.Length);
            }

            // Get returned data.
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                using (Stream responseStream = response.GetResponseStream())
                {
                    using (StreamReader readStream = new StreamReader(responseStream, Encoding.UTF8))
                    {
                        result = readStream.ReadToEnd();
                    }
                }
            }

            return result;
        }

        public static string GetSession(string apiKey, string secret, string authToken)
        {
            string host = "http://api.facebook.com/restserver.php";

            string _signature =
            "api_key="
            + apiKey
            + "auth_token=" + authToken
            + "method=Auth.getSession"
            + "v=1.0"
            + secret;

            MD5 md5 = MD5.Create();
            byte[] init = Encoding.ASCII.GetBytes(_signature);
            byte[] hash = md5.ComputeHash(init);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }

            Dictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("api_key", apiKey);
            parameters.Add("auth_token", authToken);
            parameters.Add("method", "Auth.getSession");
            parameters.Add("sig", sb.ToString().ToLower());
            parameters.Add("v", "1.0");

            StringBuilder builder = new StringBuilder();
            foreach (string key in parameters.Keys)
            {
                if (builder.Length != 0)
                    builder.Append("&");

                builder.Append(key);
                builder.Append("=");
                builder.Append(System.Web.HttpUtility.HtmlEncode(parameters[key]));
            }

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(host);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = builder.ToString().Length;

            using (Stream writeStream = request.GetRequestStream())
            {
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] bytes = encoding.GetBytes(builder.ToString());
                writeStream.Write(bytes, 0, bytes.Length);
            }

            string result = string.Empty;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                using (Stream responseStream = response.GetResponseStream())
                {
                    using (StreamReader readStream = new StreamReader(responseStream, Encoding.UTF8))
                    {
                        result = readStream.ReadToEnd();
                    }
                }
            }

            return result;
        }

        public static string GetFriends(string apiKey, string secret, string sessionKey)
        {
            string host = "http://api.facebook.com/restserver.php";
            string callid = Convert.ToString(DateTime.Now.TimeOfDay);

            string _signature =
            "api_key="
            + apiKey
            + "call_id=" + callid
            + "format=XML"
            + "method=Friends.get"
            + "session_key=" + sessionKey
            + "v=1.0"
            + secret;

            MD5 md5 = MD5.Create();
            byte[] init = Encoding.ASCII.GetBytes(_signature);
            byte[] hash = md5.ComputeHash(init);

            StringBuilder hashString = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                hashString.Append(hash[i].ToString("X2"));
            }

            Dictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("api_key", apiKey);
            parameters.Add("call_id", callid);
            parameters.Add("format", "XML");
            parameters.Add("method", "Friends.get");
            parameters.Add("sig", hashString.ToString().ToLower());
            parameters.Add("session_key", sessionKey);
            parameters.Add("v", "1.0");

            StringBuilder builder = new StringBuilder();
            foreach (string key in parameters.Keys)
            {
                if (builder.Length != 0)
                    builder.Append("&");

                builder.Append(key);
                builder.Append("=");
                builder.Append(System.Web.HttpUtility.HtmlEncode(parameters[key]));
            }

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(host);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = builder.ToString().Length;

            using (Stream writeStream = request.GetRequestStream())
            {
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] bytes = encoding.GetBytes(builder.ToString());
                writeStream.Write(bytes, 0, bytes.Length);
            }

            string result = string.Empty;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                using (Stream responseStream = response.GetResponseStream())
                {
                    using (StreamReader readStream = new StreamReader(responseStream, Encoding.UTF8))
                    {
                        result = readStream.ReadToEnd();
                    }
                }
            }

            return result;
        }
        public static void start_post(string strBuffer)
        {
            try
            {
               

            }
            catch (WebException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void PostDataToGraph(string accessToken)
        {
            //byte[] buffer = System.Text.Encoding.ASCII.GetBytes(accessToken);
            //Initialisation       
            HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create("https://graph.facebook.com/me/friends?access_token="+accessToken);
            //Our method is post, otherwise the buffer (postvars) would be useless      
            WebReq.Method = "POST";
            WebReq.UserAgent = "Windows IE 7";
            //We use form contentType, for the postvars.       
            WebReq.ContentType = "application/x-www-form-urlencoded";
            //The length of the buffer (postvars) is used as contentlength.  
          //  WebReq.ContentLength = buffer.Length;
            //We open a stream for writing the postvars        
            WebReq.Referer = "http://www.facebook.com/index.php?";
            Stream PostData = WebReq.GetRequestStream();
            //Now we write, and afterwards, we close. Closing is always important!       
           // PostData.Write(buffer, 0, buffer.Length);
            PostData.Close();
            //Get the response handle, we have no true response yet!      
            HttpWebResponse WebResp = (HttpWebResponse)WebReq.GetResponse();
            // //Let's show some information about the response      
            Console.WriteLine(WebResp.StatusCode);
            Console.WriteLine(WebResp.Server);
            //Now, we read the response (the string), and output it.      
            using (StreamReader reader = new StreamReader(WebResp.GetResponseStream()))
            {
                Console.WriteLine(reader.ReadToEnd());
            }
        }
        private static void PostData(string strBuffer)
        {
            byte[] buffer = System.Text.Encoding.ASCII.GetBytes(strBuffer);
            //Initialisation       
            HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create("https://login.facebook.com/login.php?m&next=http%3A%2F%2Fm.facebook.com%2Fhome.php");
            //Our method is post, otherwise the buffer (postvars) would be useless      
            WebReq.Method = "POST";
            WebReq.UserAgent = "Windows IE 7";
            //We use form contentType, for the postvars.       
            WebReq.ContentType = "application/x-www-form-urlencoded";
            //The length of the buffer (postvars) is used as contentlength.  
            WebReq.ContentLength = buffer.Length;
            //We open a stream for writing the postvars        
            WebReq.Referer = "http://www.facebook.com/index.php?";
            Stream PostData = WebReq.GetRequestStream();
            //Now we write, and afterwards, we close. Closing is always important!       
            PostData.Write(buffer, 0, buffer.Length);
            PostData.Close();
            //Get the response handle, we have no true response yet!      
            HttpWebResponse WebResp = (HttpWebResponse)WebReq.GetResponse();
            // //Let's show some information about the response      
            Console.WriteLine(WebResp.StatusCode);
            Console.WriteLine(WebResp.Server);
            //Now, we read the response (the string), and output it.      
            using (StreamReader reader = new StreamReader(WebResp.GetResponseStream()))
            {
                Console.WriteLine(reader.ReadToEnd());
            }
        }
        public static string ReadURL(string url)
        {
            string str = "";
            WebResponse response = ((HttpWebRequest)WebRequest.Create(url)).GetResponse();
            str = new StreamReader(response.GetResponseStream()).ReadToEnd();
            response.Close();
            return str;
        }
        private static string PostOntheWal(string query)
        {
            return ReadURL(string.Format("https://graph.facebook.com/me/friends?access_token={0}", query));
           
        }
        static void Main(string[] args)
        {
            var xmlDoc = XElement.Parse(CreateToken(API_KEY, API_SECRET));
            var authToke = xmlDoc.Value;
            var result = GetSession(API_KEY, API_SECRET, authToke);
            var friends = GetFriends(API_KEY, API_SECRET, result);
             PostDataToGraph(authToke);
            Console.WriteLine(result);
        }
    }
}
