﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Threading;
using FacebookManager.Properties;
using Microsoft.Win32;
using Application = System.Windows.Application;

namespace FacebookManager
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        #region Private variables

        public int CurrentMessagesCount;
        public string CurrentMessagesHtml = string.Empty;
        public int CurrentNotificationsCount;
        public string CurrentNotificationsHtml = string.Empty;
        public string CurrentProfileName = string.Empty;
        public DispatcherTimer dt;
        private NotifyIcon fbAlertIcon;
        private bool isUpdateRunning;

        #endregion

        public string AccessToken { get; set; }

        public bool AutoStartWithWindows
        {
            get { return Convert.ToBoolean(Settings.Default.autoStart); }
            set
            {
                Settings.Default.autoStart = value;
              //  Settings.Default.Save();
             //   RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
                if (value)
                {
                  //  string location = Assembly.GetExecutingAssembly().Location;
                  //  key.SetValue("Facebook Manager", location);
                }
                else
                {
                   // if (key != null) key.DeleteValue("Facebook Manager", false);
                }
            }
        }

        public bool IsUserLogged { get; set; }

        public bool PlaySounds
        {
            get { return Convert.ToBoolean(Settings.Default.playSounds); }
            set
            {
                Settings.Default.playSounds = value;
                Settings.Default.Save();
            }
        }

        public int RefreshTime
        {
            get { return Convert.ToInt32(Settings.Default.refreshTime); }
            set
            {
                Settings.Default.refreshTime = value;
                Settings.Default.Save();
                if ((dt != null) && dt.IsEnabled)
                {
                    dt.Interval = new TimeSpan(0, 0, value);
                }
            }
        }

        public void AddTrayIcon()
        {
            fbAlertIcon = new NotifyIcon();
            SetProperIcon();
            fbAlertIcon.Visible = true;
            fbAlertIcon.ContextMenu = new ContextMenu();
            fbAlertIcon.ContextMenu.MenuItems.Add("Go to Facebook", GoToFacebook);
            {
                fbAlertIcon.ContextMenu.MenuItems.Add("About", About_Click);
                fbAlertIcon.ContextMenu.MenuItems.Add("-");
                fbAlertIcon.ContextMenu.MenuItems.Add("E&xit", Exit_Click);
            }
            fbAlertIcon.MouseDoubleClick += ni_MouseDoubleClick;
            fbAlertIcon.MouseClick += ni_MouseClick;
            fbAlertIcon.Text = FacebookManager.Properties.Resources.App_AddTrayIcon_Facebook_Manager;
        }

        private void bw_DoWork(object sender, DoWorkEventArgs e)
        {
            List<FacebookMessage> list;
            List<FacebookMessage> list2;
            List<FacebookNotification> list3;
            List<FacebookNotification> list4;

            isUpdateRunning = true;
            if (CurrentProfileName == "")
            {
                Facebook.ReadProfileName(out CurrentProfileName);
            }
            bool flag = false;
            bool flag2 = false;
            if (Facebook.ReadMessages(out list, out list2))
            {
                flag = true;
                CurrentMessagesCount = list.Count;
                Facebook.GetHTMLForMessages(list, out CurrentMessagesHtml);
            }
            if (Facebook.ReadNotifies(out list3, out list4))
            {
                flag2 = true;
                CurrentNotificationsCount = list3.Count;
                Facebook.GetHTMLForNotifies(list3, out CurrentNotificationsHtml);
            }
            if (flag && flag2)
            {
                NewEventsSystem.PushNewEvents(list2, list4);
                fbAlertIcon.Text = string.Format("FBNotifier : {0}\nLast successfull update", CurrentProfileName);
            }
            SetProperIcon();
        }

        private void bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            isUpdateRunning = false;
            ((MainAppWindow) base.MainWindow).Refresh();
        }

        private void dt_tick(object sender, EventArgs e)
        {
            if (!isUpdateRunning)
            {
                var worker = new BackgroundWorker();
                worker.RunWorkerCompleted += bw_RunWorkerCompleted;
                worker.DoWork += bw_DoWork;
                worker.RunWorkerAsync();
            }
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
            RemoveTrayIcon();
        }

        protected void About_Click(object sender, EventArgs e)
        {
            new AboutWindow();
        }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            IsUserLogged = false;
            LoginWindow.UserLoggedIn += LoginWindow_UserLoggedIn;
            AutoStartWithWindows = Settings.Default.autoStart;
        }

        protected void Exit_Click(object sender, EventArgs e)
        {
            base.Shutdown();
        }

        protected void GoToFacebook(object sender, EventArgs e)
        {
            Process.Start("http://facebook.com");
        }

        private void LoginWindow_UserLoggedIn(object sender, EventArgs e)
        {
            IsUserLogged = true;
            AddTrayIcon();
            base.MainWindow = new MainAppWindow();
            base.ShutdownMode = ShutdownMode.OnExplicitShutdown;
            SetupTimeHandlers();
        }

        private void ni_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if ((MainWindow != null) && base.MainWindow.IsVisible)
                {
                    (MainWindow).Hide();
                }
                else
                {
                    ((MainAppWindow) MainWindow).ShowAndActivate();
                }
            }
        }

        private void ni_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                GoToFacebook(sender, e);
            }
        }

        private void RemoveTrayIcon()
        {
            if (fbAlertIcon != null)
            {
                fbAlertIcon.Dispose();
            }
        }

        private void SetProperIcon()
        {
            if (fbAlertIcon != null)
            {
                Stream stream =
                    GetResourceStream(new Uri("/FacebookManager;component/Ico/fb.ico", UriKind.Relative)).Stream;
                fbAlertIcon.Icon = new Icon(stream);
            }
        }

        private void SetupTimeHandlers()
        {
            dt = new DispatcherTimer();
            dt.Interval = new TimeSpan(0, 0, RefreshTime);
            dt.Tick += dt_tick;
            dt.Start();
            dt_tick(null, null);
        }

        protected void ShowMainWindow(object sender, EventArgs e)
        {
            ((MainAppWindow) MainWindow).ShowAndActivate();
        }
    }
}