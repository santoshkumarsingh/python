﻿using System.Collections.Generic;
using System.Threading;
using System.Windows.Threading;

namespace FacebookManager
{
    public static class NewEventsSystem
    {
        // Fields
        private static readonly AutoResetEvent eventPushedInQueue = new AutoResetEvent(false);
        private static readonly Queue<FacebookEvent> queue = new Queue<FacebookEvent>();

        // Methods
        static NewEventsSystem()
        {
            var thread = new Thread(DoWork);
            thread.IsBackground = true;
            thread.Start();
        }

        private static void DoWork()
        {
            while (true)
            {
                do
                {
                    eventPushedInQueue.WaitOne();
                } while (FBAlertWindow.NotifierWindowOpened);


                var thread = new Thread(delegate()
                                            {
                                                var w = new FBAlertWindow();
                                                w.Closed += delegate
                                                                {
                                                                    w.Dispatcher.InvokeShutdown();
                                                                    FBAlertWindow.NotifierWindowOpened = false;
                                                                };
                                                Dispatcher.Run();
                                            });
                thread.SetApartmentState(ApartmentState.STA);
                thread.IsBackground = true;
                thread.Start();
            }
        }

        private static void AlertMessage()
        {
            var thread = new Thread(delegate()
                                        {
                                            var w = new FBAlertWindow();
                                            w.Closed += delegate
                                                            {
                                                                w.Dispatcher.InvokeShutdown();
                                                                FBAlertWindow.NotifierWindowOpened = true;
                                                            };
                                            Dispatcher.Run();
                                        });
            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }

        public static bool PopEvent(ref FacebookEvent fbEvent)
        {
            if (queue.Count > 0)
            {
                fbEvent = queue.Dequeue();
                return true;
            }
            return false;
        }

        public static void PushNewEvents(List<FacebookMessage> newMessages, List<FacebookNotification> newNotifications)
        {
            foreach (FacebookMessage message in newMessages)
            {
                FacebookEvent event2;
                event2.eventType = FacebookEventTypes.Message;
                event2.subject = message.subject;
                event2.body = message.snippet;
                event2.authorName = message.snippetAuthorName;
                event2.photoUrl = string.Format("http://graph.facebook.com/{0}/picture", message.snippetAuthorId);
                event2.timeReceived = message.updatedTime;
                event2.url = string.Format("http://www.facebook.com/?sk=messages&tid={0}", message.threadId);
                queue.Enqueue(event2);
            }
            foreach (FacebookNotification notification in newNotifications)
            {
                FacebookEvent event3;
                event3.eventType = FacebookEventTypes.Notification;
                event3.subject = notification.titleText;
                event3.body = notification.bodyText;
                event3.photoUrl = string.Format("http://graph.facebook.com/{0}/picture", notification.senderId);
                event3.authorName = "";
                event3.timeReceived = notification.createdTime;
                event3.url = notification.url;
                queue.Enqueue(event3);
            }
            if (newMessages.Count > 0 || newNotifications.Count > 0)
            {
                //if ((Application.Current as App).PlaySounds)
                //{
                //    WinMMWrapper.PlayWavResource("pack://application:,,,/Sounds/notificationsound.wav");
                //}
                eventPushedInQueue.Set();
            }
        }
    }
}