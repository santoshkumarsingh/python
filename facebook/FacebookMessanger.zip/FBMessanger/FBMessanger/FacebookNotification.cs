﻿namespace FacebookManager
{
    public struct FacebookNotification
    {
        public string bodyText;
        public string createdTime;
        public string notificationId;
        public string senderId;
        public string titleText;
        public string url;

        public FacebookNotification(string notificationId, string titleText, string bodyText, string senderId,
                                    string createdTime, string url)
        {
            this.notificationId = notificationId;
            this.titleText = titleText;
            this.bodyText = bodyText;
            this.senderId = senderId;
            this.createdTime = createdTime;
            this.url = url;
        }
    }
}