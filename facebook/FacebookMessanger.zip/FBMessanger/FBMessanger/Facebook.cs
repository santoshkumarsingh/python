﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Xml;
using Microsoft.JScript;
using System.Web.Script.Serialization;
using JSON;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace FacebookManager
{
    public enum FacebookEventTypes
    {
        Message,
        Notification
    }

    public struct FacebookEvent
    {
        public string authorName;
        public string body;
        public FacebookEventTypes eventType;
        public string photoUrl;
        public string subject;
        public string timeReceived;
        public string url;
    }

    public static class Facebook
    {
        // Fields
        private static List<FacebookMessage> currentMessages = new List<FacebookMessage>();
        private static List<FacebookNotification> currentNotifications = new List<FacebookNotification>();
        private static readonly List<UserProfile> profiles = new List<UserProfile>();

        // Methods
        public static DateTime ConvertFBTimestamp(double timestamp)
        {
            var time = new DateTime(0x7b2, 1, 1, 0, 0, 0, 0);
            return time.AddSeconds(timestamp).ToLocalTime();
        }

        public static void GetHTMLForMessages(List<FacebookMessage> messages, out string html)
        {
            var builder = new StringBuilder();
            builder.AppendLine("<table width=\"100%\">");
            int num = 0;
            foreach (FacebookMessage message in messages)
            {
                num++;
                string subject = message.subject;
                string snippet = message.snippet;
                string snippetAuthorId = message.snippetAuthorId;
                string snippetAuthorName = message.snippetAuthorName;
                string timeSpanString = GetTimeSpanString(ConvertFBTimestamp(double.Parse(message.updatedTime)));
                string str6 = string.Format("http://www.facebook.com/?sk=messages&tid={0}", message.threadId);
                if ((num % 2) == 0)
                {
                    builder.AppendLine(
                        string.Format(
                            "<tr style=\"background-color: #EFF1F7\" onClick=\"window.external.LinkClicked('{0}');\" style=\"cursor:pointer\"><td>",
                            str6));
                }
                else
                {
                    builder.AppendLine(
                        string.Format(
                            "<tr onClick=\"window.external.LinkClicked('{0}');\" style=\"cursor:pointer\"><td>", str6));
                }
                string str7 = string.Format("http://graph.facebook.com/{0}/picture", snippetAuthorId);
                string str8 = "style=\"font-family: Segoe UI; color: #444; font-size: 12; font-weight: bold\"";
                string str9 = "style=\"font-family: Segoe UI; color: #444; font-size: 12;\"";
                string str10 = "style=\"font-family: Segoe UI; color: Blue; font-size: 12; font-style: italic\"";
                string str11 =
                    "style=\"font-family: Segoe UI; color: #444; font-size: 12; font-style: italic; color:Gray\"";
                string str12 =
                    string.Format(
                        "<table><tr valign=\"top\"><td><img src=\"{0}\"></td><td><span {1}>{2} : </span><span {3}>{4}</span><br/><span {5}>{6}</span><br/><span {7}>{8}</span></td></tr></table>",
                        new object[] { str7, str10, snippetAuthorName, str8, subject, str9, snippet, str11, timeSpanString });
                builder.AppendLine(str12);
                builder.AppendLine("</td></tr>");
            }
            builder.AppendLine("</table>");
            html = builder.ToString();
        }

        public static string GetHTMLForProfile()
        {
            var builder = new StringBuilder();
            builder.AppendLine("<table width=\"100%\">");
            int num = 0;
            foreach (UserProfile profile in profiles)
            {
                num++;

                string name = profile.Name;
                string imageUrl = profile.ImageUrl;
                string str6 = string.Format("http://www.facebook.com/home.php#!/profile.php?id={0}&ref=profile",
                                            profile.UserId);
                if ((num % 2) == 0)
                {
                    builder.AppendLine(
                        string.Format(
                            "<tr style=\"background-color: #EFF1F7\" onClick=\"window.external.LinkClicked('{0}');\" style=\"cursor:pointer\"><td>",
                            str6));
                }
                else
                {
                    builder.AppendLine(
                        string.Format(
                            "<tr onClick=\"window.external.LinkClicked('{0}');\" style=\"cursor:pointer\"><td>", str6));
                }
                string str7 = string.Format("http://graph.facebook.com/{0}/picture", profile.UserId);
                string str8 = "style=\"font-family: Segoe UI; color: #444; font-size: 12; font-weight: bold\"";
                string str9 = "style=\"font-family: Segoe UI; color: #444; font-size: 12;\"";
                string str10 = "style=\"font-family: Segoe UI; color: Blue; font-size: 12; font-style: italic\"";
                string str11 =
                    "style=\"font-family: Segoe UI; color: #444; font-size: 12; font-style: italic; color:Gray\"";
                string str12 =
                    string.Format(
                        "<table><tr valign=\"top\"><td><img src=\"{0}\"></td><td><span {1}>{2} : </span></td></tr></table>",
                        new object[] { str7, str10, name, str8, imageUrl, str9 });
                builder.AppendLine(str12);
                builder.AppendLine("</td></tr>");
            }
            builder.AppendLine("</table>");
            return builder.ToString();
        }

        public static void GetHTMLForNotifies(List<FacebookNotification> notifications, out string html)
        {
            var builder = new StringBuilder();
            builder.AppendLine("<table width=\"100%\">");
            int num = 0;
            foreach (FacebookNotification notification in notifications)
            {
                num++;
                string titleText = notification.titleText;
                string bodyText = notification.bodyText;
                string senderId = notification.senderId;
                string timeSpanString = GetTimeSpanString(ConvertFBTimestamp(double.Parse(notification.createdTime)));
                if ((num % 2) == 0)
                {
                    builder.AppendLine(
                        string.Format(
                            "<tr onClick=\"window.external.LinkClicked('{0}');\" style=\"background-color: #EFF1F7\" style=\"cursor:pointer\"><td>",
                            notification.url));
                }
                else
                {
                    builder.AppendLine(
                        string.Format(
                            "<tr onClick=\"window.external.LinkClicked('{0}');\" style=\"cursor:pointer\"><td>",
                            notification.url));
                }
                string str5 = string.Format("http://graph.facebook.com/{0}/picture", senderId);
                string str6 = "style=\"font-family: Segoe UI; color: #444; font-size: 12; font-weight: bold\"";
                string str7 = "style=\"font-family: Segoe UI; color: #444; font-size: 12;\"";
                string str8 =
                    "style=\"font-family: Segoe UI; color: #444; font-size: 12; font-style: italic; color:Gray\"";
                string str9 =
                    string.Format(
                        "<table><tr  valign=\"top\"><td><img src=\"{0}\"></td><td><span {1}>{2}</span><br/><span {3}>{4}</span><br/><span {5}>{6}</span></td></tr></table>",
                        new object[] { str5, str6, titleText, str7, bodyText, str8, timeSpanString });
                builder.AppendLine(str9);
                builder.AppendLine("</td></tr>");
            }
            builder.AppendLine("</table>");
            html = builder.ToString();
        }

        private static string GetMultiQueryResult(params string[] queries)
        {
            var builder = new StringBuilder("{");
            int num = 0;
            foreach (string str in queries)
            {
                num++;
                if (num > 1)
                {
                    builder.Append(",");
                }
                builder.Append(string.Format("\"query{0}\":\"{1}\"", num, str));
            }
            builder.Append("}");
            return
                HTTPReader.ReadURL(
                    string.Format("https://graph.facebook.com/fql?access_token={0}&q={1}",
                                  (Application.Current as App).AccessToken, GlobalObject.escape(builder.ToString())));
        }

        private static string GetQueryResult(string query)
        {
            return
                HTTPReader.ReadURL(string.Format(
                    "https://graph.facebook.com/fql?access_token={0}&q={1}",
                    (Application.Current as App).AccessToken, GlobalObject.escape(query)));
        }

        private static string PostOntheWal(string query)
        {
            return
                HTTPReader.ReadURL(string.Format(
                    "https://graph.facebook.com/fql?access_token={0}&q={1}",
                    (Application.Current as App).AccessToken, GlobalObject.escape(query)));
        }

        public static string GetTimeSpanString(DateTime time)
        {
            TimeSpan span = (DateTime.Now - time);
            if (span.Days == 0)
            {
                if (span.Hours == 0)
                {
                    if (span.Minutes == 0)
                    {
                        return (span.Seconds + " seconds ago");
                    }
                    if (span.Minutes == 1)
                    {
                        return (span.Minutes + " minute ago");
                    }
                    return (span.Minutes + " minutes ago");
                }
                if (span.Hours == 1)
                {
                    return (span.Hours + " hour ago");
                }
                return (span.Hours + " hours ago");
            }
            if (span.Days == 1)
            {
                return (span.Days + " day ago");
            }
            return (span.Days + " days ago");
        }

        public static string GetUnreadMessagesCount()
        {
            string query = "SELECT unread_count FROM mailbox_folder WHERE folder_id=0";
            return GetQueryResult(query);
        }

        private static bool ParseMessages(string xmlResult, out List<FacebookMessage> allMessages,
                                          out List<FacebookMessage> newMessages)
        {
            bool r = GetFriendList();
            bool flag = false;
            allMessages = new List<FacebookMessage>();
            newMessages = new List<FacebookMessage>();
            JObject j = JObject.Parse(xmlResult);
            JArray data = (JArray)j["data"];
            var dictionary = new Dictionary<string, string>();
            dynamic dynObj = JsonConvert.DeserializeObject(xmlResult);
            foreach ( var data1 in dynObj.data)
            {
                Console.WriteLine("{0}", data1.name);
                foreach (var fql in data1.fql_result_set)
                {
                    foreach (JProperty keyValue in fql)
                    {

                        Console.WriteLine("\t{0} : {1}", keyValue.Name, keyValue.Value);
                    }
                }
            }

            if (data == null)
            {
                return flag;
            }

            if (data != null)
            {
                var a = dynObj.data[1].fql_result_set;
                





                string innerText = a[0]["uid"].Value.ToString();

                        string str2 = a[0]["name"].Value.ToString();
                            dictionary[str2] = innerText;
                        
                   
                foreach (var item in dynObj.data[0].fql_result_set)
                {
                    FacebookMessage message = new FacebookMessage();
                    message.threadId = item.thread_id.Value.ToString();
                    message.updatedTime = item.updated_time.Value.ToString();
                    message.subject = item.subject.Value.ToString();
                    message.snippet = item.snippet.Value.ToString();
                    message.snippetAuthorId = item.snippet_author.Value.ToString();
                    //message.snippetAuthorName = dictionary[message.snippetAuthorId];
                    allMessages.Add(message);
                }
                using (List<FacebookMessage>.Enumerator enumerator3 = allMessages.GetEnumerator())
                {
                    Predicate<FacebookMessage> match = null;
                    FacebookMessage message;
                    while (enumerator3.MoveNext())
                    {
                        message = enumerator3.Current;
                        if (match == null)
                        {
                            match =
                                delegate(FacebookMessage m) { return (m.threadId == message.threadId) && (m.updatedTime == message.updatedTime); };
                        }
                        if (!currentMessages.Exists(match))
                        {
                            newMessages.Add(message);
                        }
                    }
                }
                currentMessages = allMessages;
            }
            return true;
        }

        public static bool ParseFriendList(string xml, List<UserProfile> profiles)
        {
            JavaScriptSerializer jss = new JavaScriptSerializer();
            jss.RegisterConverters(new JavaScriptConverter[] { new DynamicJsonConverter() });
            dynamic friendList = jss.Deserialize(xml, typeof(object)) as dynamic;
            UserProfile profile;
            if (friendList == null)
            {
                return false;
            }
            else
            {
                foreach (var friend in friendList.data)
                {

                    profile = new UserProfile();
                    profile.UserId = friend.uid.ToString();
                    profile.Name = friend.name;
                    profile.ImageUrl = friend.pic_squre;
                    profiles.Add(profile);
                }
            }
            return true;
        }

        private static bool ParseNotifications(string xml, out List<FacebookNotification> allNotifications,
                                               out List<FacebookNotification> newNotifications)
        {
            bool flag = false;
            allNotifications = new List<FacebookNotification>();
            newNotifications = new List<FacebookNotification>();
          
            var document = new XmlDocument();
            var jss = new JavaScriptSerializer();

            dynamic data = jss.Deserialize<dynamic>(xml);
           // document.LoadXml(xml);
           // var nsmgr = new XmlNamespaceManager(document.NameTable);
           // nsmgr.AddNamespace("fb", "http://api.facebook.com/1.0/");
            if (data==null)
            {
                return flag;
            }
            //XmlNodeList list2 = document.SelectNodes("fb:fql_query_response/fb:notification", nsmgr);
            if (data!=null)
            {
                foreach (Dictionary<string, object> item in data["data"])
                {
                    FacebookNotification notification;
                    var node=item;
                    notification.notificationId = node["notification_id"].ToString();
                    notification.titleText = node["title_text"].ToString();
                    notification.bodyText = node["body_text"].ToString();
                    notification.senderId = node["sender_id"].ToString();
                    notification.createdTime = node["created_time"].ToString();
                    notification.url = node["href"].ToString();
                    allNotifications.Add(notification);
                }
                using (List<FacebookNotification>.Enumerator enumerator2 = allNotifications.GetEnumerator())
                {
                    Predicate<FacebookNotification> match = null;
                    FacebookNotification notify;
                    while (enumerator2.MoveNext())
                    {
                        notify = enumerator2.Current;
                        if (match == null)
                        {
                            match =
                                delegate(FacebookNotification n) { return n.notificationId == notify.notificationId; };
                        }
                        if (!currentNotifications.Exists(match))
                        {
                            newNotifications.Add(notify);
                        }
                    }
                }
                currentNotifications = allNotifications;
            }
            return true;
        }

        public static bool GetFriendList()
        {
            string strQuery =
                "SELECT uid, name, pic_square FROM user WHERE uid = me() OR uid IN (SELECT uid2 FROM friend WHERE uid1 = me())";
            return ParseFriendList(GetQueryResult(strQuery), profiles);
        }

        public static bool ReadMessages(out List<FacebookMessage> allMessages, out List<FacebookMessage> newMessages)
        {
            string str =
                "SELECT thread_id, updated_time, subject, snippet, snippet_author FROM thread WHERE unread != 0 AND folder_id = 0";
            string str2 = "SELECT uid, name FROM user WHERE uid IN (SELECT snippet_author FROM #query1)";
            return ParseMessages(GetMultiQueryResult(new[] { str, str2 }), out allMessages, out newMessages);
        }

        public static bool ReadNotifies(out List<FacebookNotification> allNotifications,
                                        out List<FacebookNotification> newNotifications)
        {
            string query =
                "SELECT notification_id, title_text, body_text, sender_id, created_time, href FROM notification WHERE recipient_id=me() AND is_unread = 1";
            return ParseNotifications(GetQueryResult(query), out allNotifications, out newNotifications);
        }

        public static void ReadProfileName(out string profileName)
        {
            string query = "SELECT name FROM user WHERE uid = me();";
            string queryResult = GetQueryResult(query);
            JavaScriptSerializer jss = new JavaScriptSerializer();
            jss.RegisterConverters(new JavaScriptConverter[] { new DynamicJsonConverter() });
            dynamic node = jss.Deserialize(queryResult, typeof(object)) as dynamic;
            if (node != null)
            {
                profileName = node.data[0].name;
            }
            else
            {
                profileName = "connection error";
            }
        }
    }
}