﻿using DesktopAlert;

namespace FacebookManager
{
    /// <summary>
    /// Interaction logic for AboutWindow.xaml
    /// </summary>
    public partial class AboutWindow : DesktopAlertBase
    {
        public AboutWindow()
        {
            InitializeComponent();
        }
    }
}