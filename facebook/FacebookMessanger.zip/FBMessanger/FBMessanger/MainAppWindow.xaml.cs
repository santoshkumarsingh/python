﻿#define DEBUG
using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using mshtml;

namespace FacebookManager
{
    /// <summary>
    /// Interaction logic for MainAppWindow.xaml
    /// </summary>
    public partial class MainAppWindow : Window
    {
        private readonly JSEventsListener _eventListner;
        private static string _savedMessagesHtml = "";
        private static string _savedNotificationsHtml = "";
        private static string _userProfile = "";
        private static bool _isAlreadyLoaded = true;

        public MainAppWindow()
        {
            _eventListner = new JSEventsListener();
            InitializeComponent();
            SetWindowToBottomRightOfScreen();
            MouseDown += MainAppWindow_MouseDown;
        }

        private void MainAppWindow_MouseDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void Maximize(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Maximized;
        }


        internal void StartupMainWindow(object sender, EventArgs e)
        {
            Application.Current.MainWindow = this;
            Show();
        }

#if  DEBUG
        private void theForm_Initialized(object sender, EventArgs e)
        {
            messagesBrowser.NavigateToString(
                "<html><body style=\"margin:0; padding:0; overflow: auto;\" oncontextmenu=\"return false;\"><div id=\"MyDiv\"></div></body><html>");
            notificationsBrowser.NavigateToString(
                "<html><body style=\"margin:0; padding:0; overflow: auto;\" oncontextmenu=\"return false;\"><div id=\"MyDiv\"></div></body><html>");
            ProfileBrowser.NavigateToString(
                "<html><body style=\"margin:0; padding:0; overflow: auto;\" oncontextmenu=\"return false;\"><div id=\"MyDiv\"></div></body><html>");
            messagesBrowser.ObjectForScripting = _eventListner;
            notificationsBrowser.ObjectForScripting = _eventListner;
            ProfileBrowser.ObjectForScripting = _eventListner;
        }
#endif
#if  DEBUG
        public void Refresh()
        {
            string currentMessagesHtml = (Application.Current as App).CurrentMessagesHtml;
            string currentNotificationsHtml = (Application.Current as App).CurrentNotificationsHtml;
            string currentProfileName = (Application.Current as App).CurrentProfileName;
            _userProfile = Facebook.GetHTMLForProfile();
            string str4 = "FBNotifier : " + currentProfileName;
            if (str4.Length > 0x23)
            {
                str4 = str4.Substring(0, 0x23) + "...";
            }
            labelTitle.Content = str4;
            if ((Application.Current as App).CurrentMessagesCount == 0)
            {
                tabItemMessages.Header = "Messages";
                messagesBrowser.Visibility = Visibility.Collapsed;
            }
            else
            {
                tabItemMessages.Header = string.Format("Messages ({0})",
                                                       (Application.Current as App).CurrentMessagesCount);
                messagesBrowser.Visibility = Visibility.Visible;
            }
            if ((Application.Current as App).CurrentNotificationsCount == 0)
            {
                tabItemNotifications.Header = "Notifications";
                notificationsBrowser.Visibility = Visibility.Collapsed;
            }
            else
            {
                tabItemNotifications.Header = string.Format("Notifications ({0})",
                                                            (Application.Current as App).CurrentNotificationsCount);
                notificationsBrowser.Visibility = Visibility.Visible;
            }
            var document = (HTMLDocument) messagesBrowser.Document;
            var document2 = (HTMLDocument) notificationsBrowser.Document;
            var document3 = (HTMLDocument) ProfileBrowser.Document;
            if (document != null)
            {
                document.getElementById("MyDiv").innerHTML = currentMessagesHtml;
                _savedMessagesHtml = currentMessagesHtml;
            }
            if (document2 != null)
            {
                document2.getElementById("MyDiv").innerHTML = currentNotificationsHtml;
                _savedNotificationsHtml = currentNotificationsHtml;
            }
            if (document3 != null && _isAlreadyLoaded)
            {
                document3.getElementById("MyDiv").innerHTML = _userProfile;
                _isAlreadyLoaded = false;
            }
        }
#endif
#if  DEBUG
        private void SetWindowToBottomRightOfScreen()
        {
            base.Left = SystemParameters.WorkArea.Width - base.Width;
            base.Top = SystemParameters.WorkArea.Height - base.Height;
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            e.Cancel = true;
            Visibility = Visibility.Collapsed;
        }

        public void ShowAndActivate()
        {
            SetWindowToBottomRightOfScreen();
            base.Show();
            base.Activate();
            if (((Application.Current as App).CurrentNotificationsCount == 0) &&
                ((Application.Current as App).CurrentMessagesCount > 0))
            {
                tabControl1.SelectedIndex = 0;
            }
            else if (((Application.Current as App).CurrentNotificationsCount > 0) &&
                     ((Application.Current as App).CurrentMessagesCount == 0))
            {
                tabControl1.SelectedIndex = 1;
            }
            else
            {
                tabControl1.SelectedIndex = 0;
            }
        }
#endif
    }
}