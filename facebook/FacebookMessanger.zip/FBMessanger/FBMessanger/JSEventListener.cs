﻿using System.Diagnostics;
using System.Runtime.InteropServices;

namespace FacebookManager
{
    [ComVisible(true)]
    public class JSEventsListener
    {
        // Methods
        public void LinkClicked(string url)
        {
            Process.Start(url);
        }
    }
}