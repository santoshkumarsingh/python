﻿namespace FacebookManager
{
    public struct FacebookMessage
    {
        public string snippet;
        public string snippetAuthorId;
        public string snippetAuthorName;
        public string subject;
        public string threadId;
        public string updatedTime;

        public FacebookMessage(string threadId, string updatedTime, string subject, string snippet,
                               string snippetAuthorId, string snippetAuthorName)
        {
            this.threadId = threadId;
            this.updatedTime = updatedTime;
            this.subject = subject;
            this.snippet = snippet;
            this.snippetAuthorId = snippetAuthorId;
            this.snippetAuthorName = snippetAuthorName;
        }
    }
}