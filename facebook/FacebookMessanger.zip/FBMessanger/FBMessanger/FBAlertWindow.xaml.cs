﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;
using DesktopAlert;

namespace FacebookManager
{
    /// <summary>
    /// Interaction logic for FBAlertWindow.xaml
    /// </summary>
    public partial class FBAlertWindow : DesktopAlertBase
    {
        public static bool NotifierWindowOpened;

        public FBAlertWindow()
        {
            InitializeComponent();
        }

        protected override void DesktopAlertBase_Loaded(object sender, RoutedEventArgs e)
        {
            LoadNewMessage();
            base.DesktopAlertBase_Loaded(sender, e);
        }

        protected override void _activeTimer_Tick(object sender, EventArgs e)
        {
            if (!LoadNewMessage())
            {
                NotifierWindowOpened = false;
                base._activeTimer_Tick(sender, e);
            }
        }

        private bool LoadNewMessage()
        {
            var fbEvent = new FacebookEvent();
            if (!NewEventsSystem.PopEvent(ref fbEvent))
            {
                return false;
            }
            if (fbEvent.eventType == FacebookEventTypes.Message)
            {
                base.Title = "New message from " + fbEvent.authorName;
            }
            else if (fbEvent.eventType == FacebookEventTypes.Notification)
            {
                base.Title = "New notification ...";
            }
            subject.Content = fbEvent.subject;
            message.Content = fbEvent.body;
            time.Content = Facebook.ConvertFBTimestamp(double.Parse(fbEvent.timeReceived)).ToString();
            var image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri(fbEvent.photoUrl);
            image.EndInit();
            image1.Source = image;
            return true;
        }
    }
}