﻿using System.IO;
using System.Net;

namespace FacebookManager
{
    internal class HTTPReader
    {
        // Methods
        public static string ReadURL(string url)
        {
            string str = "";
            WebResponse response = (WebRequest.Create(url)).GetResponse();
            str = new StreamReader(response.GetResponseStream()).ReadToEnd();
            response.Close();
            return str;
        }
    }
}