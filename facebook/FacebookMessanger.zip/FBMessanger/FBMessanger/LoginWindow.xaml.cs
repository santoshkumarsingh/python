﻿using System;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using Application = System.Windows.Application;

namespace FacebookManager
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        private readonly string _loginUrl =
            string.Format(
                "https://graph.facebook.com/oauth/authorize?client_id={0}&redirect_uri=http://www.facebook.com/connect/login_success.html&type=user_agent&display=popup&scope=offline_access,read_mailbox,manage_notifications,read_stream,publish_stream",
                "276775795734961");

        private readonly WebBrowser _webBrowser = new WebBrowser();
        public WindowsFormsHost WebBrowserHost = new WindowsFormsHost();


        public LoginWindow()
        {
            InitializeComponent();
            base.WindowStyle = WindowStyle.None;

            var activeXInstance = (System.Windows.Controls.WebBrowser)_webBrowser.ActiveXInstance;
            Loaded += LoginWindow_Loaded;
            _webBrowser.Navigate(_loginUrl);
            _webBrowser.DocumentCompleted += webBrowser_DocumentCompleted;
        }

        internal static event EventHandler UserLoggedIn;

        private void LoginWindow_Loaded(object sender, RoutedEventArgs e)
        {
            WebBrowserHost.Child = _webBrowser;
            grid1.Children.Add(WebBrowserHost);
        }

        private void webBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            WebBrowserHost.Visibility = Visibility.Visible;
            _webBrowser.Document.Focus();
            if (_webBrowser.Url.AbsoluteUri.Contains("https://www.facebook.com/connect/login_success.html"))
            {
                if (!_webBrowser.Url.AbsoluteUri.Contains("error"))
                {
                    if (_webBrowser.Url.AbsoluteUri.Contains("access_token="))
                    {
                        int index = _webBrowser.Url.AbsoluteUri.IndexOf("access_token=");
                        ((App)Application.Current).AccessToken = _webBrowser.Url.AbsoluteUri.Split(new[] { '&' })[0];
                        ((App)Application.Current).AccessToken = ((App)Application.Current).AccessToken.Remove(0, index +
                                                                                                                 "access_token="
                                                                                                                     .
                                                                                                                     Length);
                        if (UserLoggedIn != null)
                        {
                            UserLoggedIn(this, EventArgs.Empty);
                            Close();
                        }
                    }
                }
                else
                {
                    _webBrowser.Navigate(_loginUrl);
                }
            }
        }

        private void webBrowser_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            WebBrowserHost.Visibility = Visibility.Collapsed;
        }
    }
}