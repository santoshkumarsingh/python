﻿using System;
using System.Runtime.InteropServices;

namespace FacebookManager
{
    internal class WinMmWrapper
    {
        // Fields
        public const uint SND_ASYNC = 1;
        public const uint SND_MEMORY = 4;

        // Methods
        [DllImport("Winmm.dll")]
        public static extern bool PlaySound(byte[] data, IntPtr hMod, uint dwFlags);

        public static void PlayWavResource(string path)
        {
            System.Media.SystemSounds.Asterisk.Play();
            //StreamResourceInfo resourceStream = Application.GetResourceStream(new Uri(path));
            //byte[] buffer = new byte[resourceStream.Stream.Length];
            //resourceStream.Stream.Read(buffer, 0, (int)resourceStream.Stream.Length);
            //PlaySound(buffer, IntPtr.Zero, 5);
        }
    }
}